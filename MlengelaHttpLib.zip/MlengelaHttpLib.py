# ----------------------------------------------------------------------------
# Program: MlengelaHttpLib
# Programmer: Daudi Mlengela (dnlengela@cnm.edu)(mlengelad@gmail.com)
# Instructor: Thomas Gitierrez (tgutierrez@cnm.edu)
# Date: Decmeber 10th, 2022
# Purpose: Creating web page reader in python to gather data from websites
# using Http Library & distrutils
# ----------------------------------------------------------------------------

from distutils.log import error
import http.client
import sys

def check_webserver(address, port, resource):
    #create connection
    if not resource.startswith('/'):
        resource = '/' + resource
    try:
        conn = http.client.HTTPConnection(address, port)
        print('HTTP connection created successfully')
        #make request
        req = conn.request('GET', resource)
        print('request for %s successful' % resource)
        #get response
        response = conn.getresponse()
        print('response status: %s' % response.status)
    except error as e:
        print('HTTP connection failed: %s' % e)
        return False
    finally:
        conn.close()
        print('HTTP connection closed successfully')
    if response.status in [200, 301]:
        return True
    else:
        return False

if __name__ == '__main__':
    from optparse import OptionParser
    parser = OptionParser()
    parser.add_option("-a", "--address", dest="address", default='localhost', help="ADDRESS for webserver", metavar="ADDRESS")
    parser.add_option("-p", "--port", dest="port", type="int", default=80, help="PORT for webserver", metavar="PORT")
    parser.add_option("-r", "--resource", dest="resource", default='index.html', help="RESOURCE to check", metavar="RESOURCE")
    (options, args) = parser.parse_args()
    print('options: %s, args: %s' % (options, args))
    check = check_webserver(options.address, options.port, options.resource)
    print('check_webserver returned %s' % check)
    sys.exit(not check)
